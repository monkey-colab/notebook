use crate::log::*;
use crate::params::*;

#[no_mangle]
pub unsafe extern "C" fn greet(ptr: *mut u8, size: usize) -> u64{
    let str:String = ptr_to_string(ptr, size);
    log(&str);
    let result = ["Recieved: ", &str].concat();
    string_to_ptr(result)
}
