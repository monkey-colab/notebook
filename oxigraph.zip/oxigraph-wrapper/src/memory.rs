// Allocates memory and returns a pointer to that memory
#[no_mangle]
pub unsafe extern "C" fn allocate_memory(size: usize) -> *mut u8 {
    let layout = std::alloc::Layout::from_size_align(size, 1).unwrap();
    std::alloc::alloc(layout)
}

// Deallocates memory given a pointer and size
#[no_mangle]
pub unsafe extern "C" fn deallocate_memory(ptr: *mut u8, size: usize) {
    let layout = std::alloc::Layout::from_size_align(size, 1).unwrap();
    std::alloc::dealloc(ptr, layout)
}
