/// Logs a message to the console using [`_log`].
pub fn log(message: &String) {
    unsafe {
        _log(message.as_ptr(), message.len());
    };
}

#[link(wasm_import_module = "env")]
extern "C" {
    #[link_name = "log"]
    fn _log(ptr: *const u8, size: usize);
}