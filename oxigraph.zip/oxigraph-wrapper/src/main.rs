mod memory;
mod params;
mod log;
mod greet;
mod oxigraph;

fn main(){
}