use oxigraph::io::DatasetFormat;
use oxigraph::sparql::{QueryResults, Variable};
use oxigraph::store::*;
use oxigraph::model::*;
use std::sync::Mutex;

use crate::params::*;

// Global mutable reference to an in-memory Oxigraph store
lazy_static::lazy_static! {
    static ref GRAPH_STORE: Mutex<Store> = Mutex::new(Store::new().unwrap());
}

// Loads NQuad data into the graph store.
#[no_mangle]
pub extern "C" fn load_nquads(data_ptr: *mut u8, size: usize) -> u64 {
    let data = ptr_to_string(data_ptr, size);
    let store = GRAPH_STORE.lock().unwrap();

    let result = store
        .load_dataset(data.as_ref(), DatasetFormat::NQuads, None)
        .map_err(|e| e.to_string());

    make_result_with_error(result.map(|_| ()))
}

// Clears the entire graph store.
#[no_mangle]
pub extern "C" fn clear() -> u64 {
    let store = GRAPH_STORE.lock().unwrap();
    let result = store.clear().map_err(|e| e.to_string());

    make_result_with_error(result.map(|_| ()))
}

// Executes a SPARQL query and returns the result.
#[no_mangle]
pub extern "C" fn query(q_ptr: *mut u8, size: usize) -> u64 {
    let query = ptr_to_string(q_ptr, size);
    let store = GRAPH_STORE.lock().unwrap();

    let result = store.query(query.as_str())
        .map_err(|e| e.to_string())
        .and_then(|results| match results {
            QueryResults::Boolean(result) => handle_boolean_result(result),
            QueryResults::Solutions(solutions) => handle_solutions_result(solutions),
            QueryResults::Graph(triples) => handle_graph_result(triples),
        })
        .or_else(|err_msg| handle_query_error(err_msg));

    match result {
        Ok(buffer) => {
            let len = buffer.len();
            make_wasm_result(Box::into_raw(buffer.into_boxed_slice()) as *mut u8, len)
        }
        Err(_) => 0, // Return 0 in case of an unexpected failure
    }
}

/// Handles a boolean result from a SPARQL query, encoding it as a buffer.
fn handle_boolean_result(result: bool) -> Result<Vec<u8>, String> {
    let mut buffer = Vec::with_capacity(2);
    buffer.push(1); // Type flag for boolean result
    buffer.push(if result { 1 } else { 0 }); // Boolean result (1 for true, 0 for false)
    Ok(buffer)
}

/// Handles a set of SPARQL solutions (bindings) and encodes them as a buffer.
fn handle_solutions_result(mut solutions: oxigraph::sparql::QuerySolutionIter) -> Result<Vec<u8>, String> {
    let mut buffer = Vec::with_capacity(1024);
    buffer.push(2); // Type flag for solutions

    let mut param_names = Vec::new();
    if let Some(solution) = solutions.next() {
        let solution = solution.unwrap();
        for (name, _) in solution.iter() {
            param_names.push(name.as_str().trim_start_matches('?').to_string());
        }

        buffer.extend_from_slice(&(param_names.len() as u32).to_le_bytes());
        for name in &param_names {
            write_string_to_buffer(&name, &mut buffer);
        }

        // Write the first row data
        write_row_data(&solution, &param_names, &mut buffer);
    }

    // Write remaining rows
    while let Some(solution) = solutions.next() {
        write_row_data(&solution.unwrap(), &param_names, &mut buffer);
    }

    Ok(buffer)
}

/// Handles a set of SPARQL graph results (triples) and encodes them as a buffer.
fn handle_graph_result(mut triples: oxigraph::sparql::QueryTripleIter) -> Result<Vec<u8>, String> {
    let mut buffer = Vec::with_capacity(1024);
    buffer.push(3); // Type flag for graph results

    while let Some(triple) = triples.next() {
        let triple = triple.unwrap();

        write_string_to_buffer(&triple.subject.to_string(), &mut buffer);
        write_string_to_buffer(&triple.predicate.to_string(), &mut buffer);
        write_string_to_buffer(&triple.object.to_string(), &mut buffer);
    }

    Ok(buffer)
}

/// Handles an error that occurs during query execution, encoding the error message as a buffer.
fn handle_query_error(err_msg: String) -> Result<Vec<u8>, String> {
    let err_bytes = err_msg.as_bytes();
    let mut buffer = Vec::with_capacity(err_bytes.len() + 5);
    buffer.push(0xFF); // Error flag
    buffer.extend_from_slice(&(err_bytes.len() as u32).to_le_bytes());
    buffer.extend_from_slice(err_bytes);

    Ok(buffer)
}

/// Writes a row of data from a SPARQL solution into the buffer.
fn write_row_data(solution: &oxigraph::sparql::QuerySolution, param_names: &[String], buffer: &mut Vec<u8>) {
    for param_name in param_names {
        let variable = Variable::new(param_name).unwrap();
        let value_str = match solution.get(&variable) {
            Some(Term::NamedNode(node)) => node.as_str().to_string(),
            Some(Term::Literal(literal)) => {
                if let Some(lang) = literal.language() {
                    format!("{}@{}", literal.value(), lang)
                } else if literal.datatype().as_str() == "http://www.w3.org/2001/XMLSchema#string" {
                    literal.value().to_string()
                } else {
                    format!("{}^^{}", literal.value(), literal.datatype().as_str())
                }
            }
            Some(Term::BlankNode(bnode)) => bnode.as_str().to_string(),
            _ => "".to_string(),
        };

        write_string_to_buffer(&value_str, buffer);
    }
}

// Executes a SPARQL update query and returns the result.
#[no_mangle]
pub extern "C" fn update(q_ptr: *mut u8, size: usize) -> u64 {
    let query = ptr_to_string(q_ptr, size);
    let store = GRAPH_STORE.lock().unwrap();

    let result = store.update(query.as_str()).map_err(|e| e.to_string());

    make_result_with_error(result.map(|_| ()))
}
