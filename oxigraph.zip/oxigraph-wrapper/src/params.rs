use std::slice;

// Converts a raw pointer to a UTF-8 string slice, assuming ownership of the memory.
pub fn ptr_to_string(ptr: *mut u8, size: usize) -> String {
    unsafe {
        let slice = slice::from_raw_parts_mut(ptr, size);
        std::str::from_utf8_unchecked_mut(slice).to_string()
    }
}

// Takes ownership of a String and returns a pointer-sized u64 representation.
// Forgets the original String to prevent deallocation.
pub fn string_to_ptr(s: String) -> u64 {
    let result = make_wasm_result(s.as_ptr(), s.len());
    std::mem::forget(s);
    result
}

// Encodes a pointer and size as a single u64 value.
pub fn make_wasm_result(ptr: *const u8, size: usize) -> u64 {
    ((ptr as u64) << 32) | size as u64
}

// Writes a UTF-8 string to a buffer, prefixed with its length as a 4-byte little-endian integer.
pub fn write_string_to_buffer(s: &str, buffer: &mut Vec<u8>) {
    let s_bytes = s.as_bytes();
    buffer.extend_from_slice(&(s_bytes.len() as u32).to_le_bytes());
    buffer.extend_from_slice(s_bytes);
}

// Creates a WASM result from a Rust `Result`, returning success (0) or error with a message.
pub fn make_result_with_error(result: Result<(), String>) -> u64 {
    match result {
        Ok(()) => {
            let mut buffer = Vec::with_capacity(1);
            buffer.push(0); // Success flag
            make_wasm_result(Box::into_raw(buffer.into_boxed_slice()) as *mut u8, 1)
        }
        Err(err_msg) => {
            let err_bytes = err_msg.as_bytes();
            let err_len = err_bytes.len() as u32;
            let mut buffer = Vec::with_capacity(err_len as usize + 1 + 4);

            buffer.push(1); // Error flag
            buffer.extend_from_slice(&err_len.to_le_bytes());
            buffer.extend_from_slice(err_bytes);

            let len = buffer.len();
            make_wasm_result(Box::into_raw(buffer.into_boxed_slice()) as *mut u8, len)
        }
    }
}
