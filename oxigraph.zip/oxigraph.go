package main

import (
	_ "embed"
	"errors"
	"fmt"
	"sync"
	"unsafe"
)

//go:embed oxigraph-wrapper/wasm/oxigraph-wrapper.wasm
var oxigraphWrapper []byte

// Oxigraph manages the WASM instance and its associated functions for SPARQL querying.
type Oxigraph struct {
	loadNQuadsFn *Function
	clearFn      *Function
	queryFn      *Function
	updateFn     *Function
	wasm         *WASMManager
}

var (
	oxigraphInstance  *Oxigraph
	oxigraphOnce      sync.Once
	oxigraphInitError error
)

// NewOxigraphInstance initializes and returns a singleton instance of Oxigraph.
func NewOxigraphInstance(memory uint32) (*Oxigraph, error) {
	oxigraphOnce.Do(func() {
		wasm, err := NewWASMManager(oxigraphWrapper, false, memory)
		if err != nil {
			oxigraphInitError = fmt.Errorf("failed to initialize WASM manager: %v", err)
			return
		}

		oxigraphInstance, oxigraphInitError = initializeOxigraph(wasm)
	})

	if oxigraphInitError != nil {
		return nil, oxigraphInitError
	}

	return oxigraphInstance, nil
}

// initializeOxigraph sets up Oxigraph functions.
func initializeOxigraph(wasm *WASMManager) (*Oxigraph, error) {
	loadNQuadsFn, err := wasm.NewFunction("load_nquads")
	if err != nil {
		return nil, fmt.Errorf("failed to load load_nquads function: %v", err)
	}

	clearFn, err := wasm.NewFunction("clear")
	if err != nil {
		return nil, fmt.Errorf("failed to load clear function: %v", err)
	}

	queryFn, err := wasm.NewFunction("query")
	if err != nil {
		return nil, fmt.Errorf("failed to load query function: %v", err)
	}

	updateFn, err := wasm.NewFunction("update")
	if err != nil {
		return nil, fmt.Errorf("failed to load update function: %v", err)
	}

	return &Oxigraph{
		loadNQuadsFn: loadNQuadsFn,
		clearFn:      clearFn,
		queryFn:      queryFn,
		updateFn:     updateFn,
		wasm:         wasm,
	}, nil
}

// LoadNQuads loads the provided N-Quads data into the Oxigraph store.
func (o *Oxigraph) LoadNQuads(nquads string) error {
	quadData, err := o.wasm.NewStringParam(nquads)
	if err != nil {
		return fmt.Errorf("failed to create nquad param: %v", err)
	}
	defer quadData.Free()

	result, err := o.loadNQuadsFn.CallWithResult([]Param{quadData})
	if err != nil {
		return fmt.Errorf("failed to call load_nquads function: %v", err)
	}
	defer result.Free()

	return parseResult(result)
}

// Clear removes all quads from the Oxigraph store.
func (o *Oxigraph) Clear() error {
	result, err := o.clearFn.CallWithResult([]Param{})
	if err != nil {
		return fmt.Errorf("failed to call clear function: %v", err)
	}

	defer result.Free()

	return parseResult(result)
}

// Update executes an update query on the Oxigraph store.
func (o *Oxigraph) Update(query string) error {
	queryParam, err := o.wasm.NewStringParam(query)
	if err != nil {
		return fmt.Errorf("failed to create query param: %v", err)
	}
	defer queryParam.Free()

	result, err := o.updateFn.CallWithResult([]Param{queryParam})
	if err != nil {
		return fmt.Errorf("failed to call update function: %v", err)
	}
	defer result.Free()

	return parseResult(result)
}

// Query executes a SPARQL query (ASK, CONSTRUCT, or SELECT) and returns the results.
func (o *Oxigraph) Query(query string) (*QueryResult, error) {
	queryParam, err := o.wasm.NewStringParam(query)
	if err != nil {
		return nil, fmt.Errorf("failed to create query param: %v", err)
	}
	defer queryParam.Free()

	result, err := o.queryFn.CallWithResult([]Param{queryParam})
	if err != nil {
		return nil, fmt.Errorf("failed to call query function: %v", err)
	}

	return parseQueryResult(result)
}

// parseQueryResult parses the result of a SPARQL query and returns a corresponding QueryResult.
func parseQueryResult(result *Result) (*QueryResult, error) {
	data, err := result.Read()
	if err != nil {
		result.Free()
		return nil, fmt.Errorf("failed to read result: %v", err)
	}

	if len(data) == 0 {
		result.Free()
		return nil, errors.New("invalid data")
	}

	resultType := data[0]
	data = data[1:]

	var queryResult *QueryResult
	switch resultType {
	case 1: // ASK query result
		queryResult, err = parseAskResult(data)

	case 2: // SELECT query result
		queryResult, err = parseSelectResult(data)

	case 3: // CONSTRUCT query result
		queryResult, err = parseConstructResult(data)

	default:
		msg, _ := readError(data)
		result.Free()
		return nil, fmt.Errorf("failed to execute query: %s", msg)
	}

	if err != nil {
		result.Free()
		return nil, err
	}

	queryResult.Result = *result
	return queryResult, nil
}

// parseAskResult parses an ASK query result.
func parseAskResult(data []byte) (*QueryResult, error) {
	if len(data) < 1 {
		return nil, errors.New("invalid ASK result data")
	}
	result := &QueryResult{
		Type:      "ASK",
		AskResult: (*bool)(unsafe.Pointer(&data[0])),
	}
	return result, nil
}

// parseSelectResult parses a SELECT query result.
func parseSelectResult(data []byte) (*QueryResult, error) {
	if len(data) < 4 {
		return nil, errors.New("invalid SELECT result data")
	}

	numParams := int(*(*uint32)(unsafe.Pointer(&data[0])))
	offset := 4

	headers := make([]string, numParams)
	for i := 0; i < numParams; i++ {
		nameSize := int(*(*uint32)(unsafe.Pointer(&data[offset])))
		offset += 4

		headers[i] = bytesToString(data[offset : offset+nameSize])
		offset += nameSize
	}

	rows := make([]map[string]string, 0)
	for offset < len(data) {
		row := make(map[string]string)
		for _, header := range headers {
			valueSize := int(*(*uint32)(unsafe.Pointer(&data[offset])))
			offset += 4

			row[header] = bytesToString(data[offset : offset+valueSize])
			offset += valueSize
		}
		rows = append(rows, row)
	}

	return &QueryResult{
		Type:         "SELECT",
		SelectResult: &SelectQueryResult{Headers: headers, Rows: rows},
	}, nil
}

// parseConstructResult parses a CONSTRUCT query result.
func parseConstructResult(data []byte) (*QueryResult, error) {
	if len(data) < 4 {
		return nil, errors.New("invalid CONSTRUCT result data")
	}

	numTriples := int(*(*uint32)(unsafe.Pointer(&data[0])))
	offset := 4

	triples := make([]Triple, numTriples)
	for i := 0; i < numTriples; i++ {
		subjectSize := int(*(*uint32)(unsafe.Pointer(&data[offset])))
		offset += 4
		subject := bytesToString(data[offset : offset+subjectSize])
		offset += subjectSize

		predicateSize := int(*(*uint32)(unsafe.Pointer(&data[offset])))
		offset += 4
		predicate := bytesToString(data[offset : offset+predicateSize])
		offset += predicateSize

		objectSize := int(*(*uint32)(unsafe.Pointer(&data[offset])))
		offset += 4
		object := bytesToString(data[offset : offset+objectSize])
		offset += objectSize

		triples[i] = Triple{
			Subject:   subject,
			Predicate: predicate,
			Object:    object,
		}
	}

	return &QueryResult{
		Type:            "CONSTRUCT",
		ConstructResult: &ConstructQueryResult{Triples: triples},
	}, nil
}

// parseResult checks for success or reads the error message in the result.
func parseResult(result *Result) error {
	data, err := result.Read()
	if err != nil {
		return fmt.Errorf("failed to read result: %v", err)
	}

	if len(data) == 0 {
		return errors.New("no data returned")
	}

	if data[0] == 0 {
		return nil
	}

	msg, err := readError(data[1:])
	if err != nil {
		return err
	}

	return fmt.Errorf("error from oxigraph: %v", msg)
}

// readError reads the error message from the result data.
func readError(data []byte) (string, error) {
	if len(data) < 4 {
		return "", errors.New("invalid error data")
	}

	msgSize := int(*(*uint32)(unsafe.Pointer(&data[0])))
	msg := bytesToString(data[4 : 4+msgSize])

	return msg, nil
}

// SelectQueryResult holds the results of a SELECT query.
type SelectQueryResult struct {
	Headers []string
	Rows    []map[string]string
}

// ConstructQueryResult holds the results of a CONSTRUCT query.
type ConstructQueryResult struct {
	Triples []Triple
}

// Triple represents an RDF triple.
type Triple struct {
	Subject   string
	Predicate string
	Object    string
}

// QueryResult is a union type to hold results for different query types.
type QueryResult struct {
	Type            string
	AskResult       *bool
	SelectResult    *SelectQueryResult
	ConstructResult *ConstructQueryResult
	Result
}

// GetRow returns the data for a specific row in the SelectQueryResult.
func (r *SelectQueryResult) GetRow(index int) (map[string]string, error) {
	if index >= len(r.Rows) {
		return nil, errors.New("index out of bounds")
	}
	return r.Rows[index], nil
}

// GetByParam returns the data for a specific parameter in a specific row in SelectQueryResult.
func (r *SelectQueryResult) GetByParam(row int, param string) (string, error) {
	if row >= len(r.Rows) {
		return "", errors.New("row index out of bounds")
	}
	value, ok := r.Rows[row][param]
	if !ok {
		return "", errors.New("parameter not found")
	}
	return value, nil
}

// bytesToString converts a byte slice to a string without copying.
func bytesToString(b []byte) string {
	p := unsafe.SliceData(b)
	return unsafe.String(p, len(b))
}
