package main

import (
	"testing"
)

// TestNewOxigraphInstance tests the initialization of the Oxigraph instance.
func TestNewOxigraphInstance(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}
	if instance == nil {
		t.Fatal("Expected Oxigraph instance, got nil")
	}
}

// TestLoadNQuads tests loading N-Quads data into Oxigraph.
func TestLoadNQuads(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}

	nquads := `
	<http://example.org/alice> <http://example.org/name> "Alice" .
	<http://example.org/alice> <http://example.org/birthDate> "1985-06-15"^^<http://www.w3.org/2001/XMLSchema#date> .
	<http://example.org/alice> <http://example.org/income> "50000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
	<http://example.org/alice> <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> .
	<http://example.org/bob> <http://example.org/name> "Bob" .
	<http://example.org/bob> <http://example.org/birthDate> "1990-07-22"^^<http://www.w3.org/2001/XMLSchema#date> .
	<http://example.org/bob> <http://example.org/income> "60000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
	<http://example.org/bob> <http://example.org/employed> "false"^^<http://www.w3.org/2001/XMLSchema#boolean> .
	<http://example.org/charlie> <http://example.org/name> "Charlie" .
	<http://example.org/charlie> <http://example.org/birthDate> "1982-11-30"^^<http://www.w3.org/2001/XMLSchema#date> .
	<http://example.org/charlie> <http://example.org/income> "70000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
	<http://example.org/charlie> <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> .
	<http://example.org/david> <http://example.org/name> "David" .
	<http://example.org/david> <http://example.org/birthDate> "1988-03-10"^^<http://www.w3.org/2001/XMLSchema#date> .
	<http://example.org/david> <http://example.org/income> "80000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
	<http://example.org/david> <http://example.org/employed> "false"^^<http://www.w3.org/2001/XMLSchema#boolean> .
	<http://example.org/alice> <http://example.org/knows> <http://example.org/bob> .
	<http://example.org/alice> <http://example.org/knows> <http://example.org/charlie> .
	<http://example.org/bob> <http://example.org/knows> <http://example.org/david> .
	<http://example.org/charlie> <http://example.org/knows> <http://example.org/david> .`

	err = instance.LoadNQuads(nquads)
	if err != nil {
		t.Fatalf("Failed to load N-Quads data: %v", err)
	}
}

// TestSelectQuery tests executing a SPARQL SELECT query.
func TestSelectQuery(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}

	nquads := `
	<http://example.org/alice> <http://example.org/name> "Alice" .
	<http://example.org/bob> <http://example.org/name> "Bob" .
	<http://example.org/charlie> <http://example.org/name> "Charlie" .`

	err = instance.LoadNQuads(nquads)
	if err != nil {
		t.Fatalf("Failed to load N-Quads data: %v", err)
	}

	query := `SELECT ?s ?name WHERE { ?s <http://example.org/name> ?name }`
	queryResult, err := instance.Query(query)
	if err != nil {
		t.Fatalf("Failed to execute SELECT query: %v", err)
	}
	defer queryResult.Free()

	if len(queryResult.SelectResult.Headers) != 2 || queryResult.SelectResult.Headers[0] != "s" || queryResult.SelectResult.Headers[1] != "name" {
		t.Fatalf("Unexpected headers: %v", queryResult.SelectResult.Headers)
	}

	expectedRows := map[string]map[string]string{
		"http://example.org/alice":   {"name": "Alice"},
		"http://example.org/bob":     {"name": "Bob"},
		"http://example.org/charlie": {"name": "Charlie"},
	}

	for i, row := range queryResult.SelectResult.Rows {
		subject := row["s"]
		name := row["name"]
		expectedName, exists := expectedRows[subject]
		if !exists || expectedName["name"] != name {
			t.Fatalf("Unexpected row %d: %v", i, row)
		}
	}
}

// TestAskQuery tests executing a SPARQL ASK query.
func TestAskQuery(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}

	nquads := `
	<http://example.org/alice> <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> .`

	err = instance.LoadNQuads(nquads)
	if err != nil {
		t.Fatalf("Failed to load N-Quads data: %v", err)
	}

	askQuery := `ASK { ?s <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> }`
	askResult, err := instance.Query(askQuery)
	if err != nil {
		t.Fatalf("Failed to execute ASK query: %v", err)
	}
	defer askResult.Free()

	if *askResult.AskResult != true {
		t.Fatalf("Expected ASK result true, got %v", *askResult.AskResult)
	}
}

// TestUpdateQuery tests executing a SPARQL UPDATE query.
func TestUpdateQuery(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}

	updateQuery := `INSERT DATA { <http://example.org/alice> <http://example.org/age> "30"^^<http://www.w3.org/2001/XMLSchema#integer> . }`
	err = instance.Update(updateQuery)
	if err != nil {
		t.Fatalf("Failed to execute UPDATE query: %v", err)
	}

	// Verify by running a SELECT query
	selectQuery := `SELECT ?s ?age WHERE { ?s <http://example.org/age> ?age }`
	queryResult, err := instance.Query(selectQuery)
	if err != nil {
		t.Fatalf("Failed to execute SELECT query: %v", err)
	}
	defer queryResult.Free()

	if len(queryResult.SelectResult.Rows) != 1 {
		t.Fatalf("Expected 1 row, got %d", len(queryResult.SelectResult.Rows))
	}

	row := queryResult.SelectResult.Rows[0]
	if row["s"] != "http://example.org/alice" || row["age"] != "30" {
		t.Fatalf("Unexpected row data: %v", row)
	}
}

// TestConstructQuery tests executing a SPARQL CONSTRUCT query.
func TestConstructQuery(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}

	nquads := `
	<http://example.org/alice> <http://example.org/age> "30"^^<http://www.w3.org/2001/XMLSchema#integer> .`

	err = instance.LoadNQuads(nquads)
	if err != nil {
		t.Fatalf("Failed to load N-Quads data: %v", err)
	}

	constructQuery := `CONSTRUCT { ?s <http://example.org/hasAge> ?age } WHERE { ?s <http://example.org/age> ?age }`
	queryResult, err := instance.Query(constructQuery)
	if err != nil {
		t.Fatalf("Failed to execute CONSTRUCT query: %v", err)
	}
	defer queryResult.Free()

	if len(queryResult.ConstructResult.Triples) != 1 {
		t.Fatalf("Expected 1 triple, got %d", len(queryResult.ConstructResult.Triples))
	}

	triple := queryResult.ConstructResult.Triples[0]
	if triple.Subject != "<http://example.org/alice>" || triple.Predicate != "<http://example.org/hasAge>" || triple.Object != "\"30\"^^<http://www.w3.org/2001/XMLSchema#integer>" {
		t.Fatalf("Unexpected triple: %v", triple)
	}
}

// TestClearData tests clearing the data from the Oxigraph instance.
func TestClearData(t *testing.T) {
	instance, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		t.Fatalf("Failed to create Oxigraph instance: %v", err)
	}

	nquads := `
	<http://example.org/alice> <http://example.org/name> "Alice" .`

	err = instance.LoadNQuads(nquads)
	if err != nil {
		t.Fatalf("Failed to load N-Quads data: %v", err)
	}

	clearQuery := `CLEAR GRAPH <http://example.org/alice>`
	err = instance.Update(clearQuery)
	if err != nil {
		t.Fatalf("Failed to execute CLEAR query: %v", err)
	}

	// Verify by running a SELECT query
	selectQuery := `SELECT ?s ?p ?o WHERE { ?s ?p ?o }`
	queryResult, err := instance.Query(selectQuery)
	if err != nil {
		t.Fatalf("Failed to execute SELECT query: %v", err)
	}
	defer queryResult.Free()

	if len(queryResult.SelectResult.Rows) != 0 {
		t.Fatalf("Expected 0 rows after CLEAR, got %d", len(queryResult.SelectResult.Rows))
	}
}
