package main

import (
	"context"
	"errors"
	"fmt"
	"log"

	"github.com/tetratelabs/wazero"
	"github.com/tetratelabs/wazero/api"
	"github.com/tetratelabs/wazero/imports/wasi_snapshot_preview1"
)

// WASMManager manages the lifecycle and interaction with a WASM module.
type WASMManager struct {
	context      context.Context
	runtime      wazero.Runtime
	module       api.Module
	allocateFn   api.Function
	deallocateFn api.Function
	memory       api.Memory
}

// NewWASMManager initializes a new WASMManager with the provided WASM binary.
func NewWASMManager(wasmBinary []byte, compile bool, initMemory uint32) (*WASMManager, error) {
	ctx := context.Background()

	// Choose between the interpreter or compiled mode.
	config := wazero.NewRuntimeConfigInterpreter()
	if compile {
		config = wazero.NewRuntimeConfigCompiler()
	}

	// Set initial memory configuration if specified.
	if initMemory != 0 {
		config = config.WithMemoryLimitPages(initMemory / 65536).WithMemoryCapacityFromMax(true)
	}

	runtime := wazero.NewRuntimeWithConfig(ctx, config)

	// Instantiate the host module for logging.
	_, err := runtime.NewHostModuleBuilder("env").
		NewFunctionBuilder().WithFunc(logString).Export("log").Instantiate(ctx)
	if err != nil {
		return nil, err
	}

	// Instantiate the WASI module.
	wasi_snapshot_preview1.MustInstantiate(ctx, runtime)

	// Instantiate the provided WASM binary.
	module, err := runtime.Instantiate(ctx, wasmBinary)
	if err != nil {
		return nil, err
	}

	// Access the module memory.
	memory := module.Memory()
	if memory == nil {
		return nil, errors.New("failed to access module memory")
	}

	// Export and validate the allocate and deallocate functions.
	allocateFn := module.ExportedFunction("allocate_memory")
	if allocateFn == nil {
		return nil, errors.New("unable to find allocate_memory function")
	}

	deallocateFn := module.ExportedFunction("deallocate_memory")
	if deallocateFn == nil {
		return nil, errors.New("unable to find deallocate_memory function")
	}

	return &WASMManager{
		context:      ctx,
		runtime:      runtime,
		module:       module,
		allocateFn:   allocateFn,
		deallocateFn: deallocateFn,
		memory:       memory,
	}, nil
}

// Memory represents a block of allocated memory in WASM.
type Memory struct {
	data    uintptr
	size    int
	manager *WASMManager
}

// NewMemory allocates a new block of memory in WASM and returns a pointer to it.
func (m *WASMManager) NewMemory(size int) (*Memory, error) {
	results, err := m.allocateFn.Call(m.context, uint64(size))
	if err != nil {
		return nil, fmt.Errorf("failed to allocate memory: %w", err)
	}
	if len(results) == 0 {
		return nil, errors.New("allocate function did not return a result")
	}

	data := uintptr(results[0])
	return &Memory{
		data:    data,
		size:    size,
		manager: m,
	}, nil
}

// Free deallocates a previously allocated block of memory in WASM.
func (m *Memory) Free() error {
	_, err := m.manager.deallocateFn.Call(m.manager.context, uint64(m.data), uint64(m.size))
	if err != nil {
		return fmt.Errorf("failed to deallocate memory: %w", err)
	}
	return nil
}

// Write writes data into the allocated memory block in WASM.
func (m *Memory) Write(data []byte) error {
	if len(data) > m.size {
		return errors.New("data size is larger than the allocated memory")
	}
	if !m.manager.memory.Write(uint32(m.data), data) {
		return errors.New("failed to write to memory")
	}
	return nil
}

// Read reads data from the allocated memory block in WASM.
func (m *Memory) Read() ([]byte, error) {
	data, read := m.manager.memory.Read(uint32(m.data), uint32(m.size))
	if !read {
		return nil, errors.New("failed to read memory")
	}
	return data, nil
}

// Param is an interface for parameters to be passed to a WASM function.
type Param interface {
	getValues() []uint64
}

// SimpleParam represents a simple param to be passed to a WASM function.
type SimpleParam struct {
	val uint64
}

// NewSimpleParam creates a new SimpleParam.
func NewSimpleParam(val uint64) *SimpleParam {
	return &SimpleParam{val}
}

// getValues returns the underlying value of SimpleParam.
func (p *SimpleParam) getValues() []uint64 {
	return []uint64{p.val}
}

// MemoryParam represents a memory param to be passed to a WASM function.
type MemoryParam struct {
	Memory
}

// getValues returns the memory address and size.
func (p *MemoryParam) getValues() []uint64 {
	return []uint64{uint64(p.data), uint64(p.size)}
}

// NewMemoryParam creates a new MemoryParam and writes the given data to it.
func (m *WASMManager) NewMemoryParam(data []byte, size int) (*MemoryParam, error) {
	mem, err := m.NewMemory(size)
	if err != nil {
		return nil, fmt.Errorf("failed to allocate memory for param: %w", err)
	}

	if err = mem.Write(data); err != nil {
		return nil, fmt.Errorf("failed to write param data: %w", err)
	}

	return &MemoryParam{Memory: *mem}, nil
}

// StringParam represents a string param to be passed to WASM function.
type StringParam struct {
	MemoryParam
}

// NewStringParam creates a new StringParam from a string.
func (m *WASMManager) NewStringParam(value string) (*StringParam, error) {
	p, err := m.NewMemoryParam([]byte(value), len(value))
	if err != nil {
		return nil, err
	}
	return &StringParam{MemoryParam: *p}, nil
}

// Result represents the result from the WASM module.
type Result struct {
	Memory
}

// NewResult creates a new Result object from a pointer.
func (m *WASMManager) NewResult(ptr uint64) *Result {
	uptr := uint32(ptr >> 32)
	size := uint32(ptr)
	return &Result{
		Memory{
			data:    uintptr(uptr),
			size:    int(size),
			manager: m,
		},
	}
}

// Function represents a callable function in the WASM module.
type Function struct {
	fn      api.Function
	manager *WASMManager
}

// NewFunction creates a new Function object by looking up a function by name in the WASM module.
func (m *WASMManager) NewFunction(name string) (*Function, error) {
	fn := m.module.ExportedFunction(name)
	if fn == nil {
		return nil, fmt.Errorf("unable to find function %s", name)
	}
	return &Function{fn, m}, nil
}

// CallWithResult calls the function with the provided parameters and returns the result.
func (f *Function) CallWithResult(params []Param) (*Result, error) {
	rval, err := f.Call(params)
	if err != nil {
		return nil, fmt.Errorf("failed to call function: %w", err)
	}
	if rval == 0 {
		return nil, errors.New("memory function returned null")
	}
	return f.manager.NewResult(rval), nil
}

// Call calls the function with the provided parameters and returns the raw result.
func (f *Function) Call(params []Param) (uint64, error) {
	var stack []uint64
	for _, p := range params {
		stack = append(stack, p.getValues()...)
	}

	err := f.fn.CallWithStack(f.manager.context, stack)
	if err != nil {
		return 0, fmt.Errorf("failed to call function: %w", err)
	}

	return stack[0], nil
}

// logString logs a string from the WASM module memory to the console.
func logString(ctx context.Context, m api.Module, offset, byteCount uint32) {
	buf, ok := m.Memory().Read(offset, byteCount)
	if !ok {
		log.Panicf("Memory.Read(%d, %d) out of range", offset, byteCount)
	}
	fmt.Println(string(buf))
}
