package main

import (
	"fmt"
	"log"
)

func main() {

	oxigraph, err := NewOxigraphInstance(128 * 1024 * 1024)
	if err != nil {
		log.Fatalf("Failed to create store: %v", err)
	}

	// Sample N-Quads data
	nquads := `
	<http://example.org/alice> <http://example.org/name> "Alice" .
	<http://example.org/alice> <http://example.org/birthDate> "1985-06-15"^^<http://www.w3.org/2001/XMLSchema#date> .
	<http://example.org/alice> <http://example.org/income> "50000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
    <http://example.org/alice> <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> .
    <http://example.org/bob> <http://example.org/name> "Bob" .
    <http://example.org/bob> <http://example.org/birthDate> "1990-07-22"^^<http://www.w3.org/2001/XMLSchema#date> .
    <http://example.org/bob> <http://example.org/income> "60000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
    <http://example.org/bob> <http://example.org/employed> "false"^^<http://www.w3.org/2001/XMLSchema#boolean> .
    <http://example.org/charlie> <http://example.org/name> "Charlie" .
    <http://example.org/charlie> <http://example.org/birthDate> "1982-11-30"^^<http://www.w3.org/2001/XMLSchema#date> .
    <http://example.org/charlie> <http://example.org/income> "70000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
    <http://example.org/charlie> <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> .
    <http://example.org/david> <http://example.org/name> "David" .
    <http://example.org/david> <http://example.org/birthDate> "1988-03-10"^^<http://www.w3.org/2001/XMLSchema#date> .
    <http://example.org/david> <http://example.org/income> "80000.00"^^<http://www.w3.org/2001/XMLSchema#decimal> .
    <http://example.org/david> <http://example.org/employed> "false"^^<http://www.w3.org/2001/XMLSchema#boolean> .
    <http://example.org/alice> <http://example.org/knows> <http://example.org/bob> .
    <http://example.org/alice> <http://example.org/knows> <http://example.org/charlie> .
    <http://example.org/bob> <http://example.org/knows> <http://example.org/david> .
    <http://example.org/charlie> <http://example.org/knows> <http://example.org/david> .`

	// Load the N-Quads data into the store
	if err := oxigraph.LoadNQuads(nquads); err != nil {
		log.Fatalf("Failed to load N-Quads: %v", err)
	}

	// SPARQL SELECT query
	query := `SELECT ?s ?name WHERE { ?s <http://example.org/name> ?name }`

	// Execute the query and get results
	queryResult, err := oxigraph.Query(query)
	if err != nil {
		log.Fatalf("failed to execute query: %v", err)
	}
	defer queryResult.Free()

	// Print headers
	fmt.Println("Headers:", queryResult.SelectResult.Headers)

	// Print rows
	for i, row := range queryResult.SelectResult.Rows {
		fmt.Printf("Row %d:\n", i)
		for key, value := range row {
			fmt.Printf("  %s: %s\n", key, value)
		}
	}

	askQuery := `ASK { ?s <http://example.org/employed> "true"^^<http://www.w3.org/2001/XMLSchema#boolean> }`

	askResult, err := oxigraph.Query(askQuery)
	if err != nil {
		log.Fatalf("Failed to execute query: %v", err)
	}

	defer askResult.Free()

	fmt.Println("Ask result:", *askResult.AskResult)
}
